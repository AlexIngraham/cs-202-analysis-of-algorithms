
import java.util.*;
import java.io.*;

public class Fib {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        long t0 = System.currentTimeMillis();
        long ans = fib4(n);
        long t1 = System.currentTimeMillis();
        System.out.println(ans);
        System.out.println("time: " + (t1 - t0));
    }

    // return n-th fibonacci number, exponential time
    static long fib1(int n) {
        if (n < 2) {
            return n;
        }
        return fib1(n - 1) + fib1(n - 2);
    }

    // compute n-th fibonacci number by remembering previous numbers
    static long fib2(int n) {
        long[] F = new long[n + 1];
        F[0] = 0;
        F[1] = 1;
        for (int i = 2; i <= n; i++) {
            F[i] = F[i - 1] + F[i - 2];
        }
        return F[n];
    }

    // using less space
    static long fib3(int n) {
        long a = 0; // F[0]
        long b = 1; // F[1];
        for (int i = 2; i <= n; i++) {
            long c = a + b;
            a = b;
            b = c;
        }
        return b;
    }

    // using memorization dp
    static long fib4(int n) {
        long[] F = new long[n + 1];
        return findFib(F, n);
    }

    // O(n) time
    static long findFib(long[] F, int n) {
        if (n < 2) {
            return n;
        }
        if (F[n] > 0) {
            return F[n]; // f[n] is previously computed

        }
        return F[n] = findFib(F, n - 1) + findFib(F, n - 2);
    }
}

public class GCD {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        long a = in.nextLong(); // to handle large number, int is too small
        long b = in.nextLong();

        // return gcd of a and b, Euclid's algorithm test
        long x = System.currentTimeMillis();
        long y = gcd1(a, b);
        long z = System.currentTimeMillis();

        System.out.println("GCD: " + y);
        System.out.println("time: " + (z - x));

        // brute force test
        if (Math.min(a, b) <= 1000000) {
            long startTime = System.currentTimeMillis();
            long bruteForceGCD = gcd2(a, b);
            long endTime = System.currentTimeMillis();
            System.out.println("Brute force GCD: " + bruteForceGCD);
            System.out.println("time: " + (endTime - startTime));
        }
    }

// elucid's algorithm, O(log(min(a,b))) time
    static long gcd1(long a, long b) {
        if (b == 0) {
            return a;
        }
        return gcd1(b, a % b);
    }

// brute force, O(min(a,b)) time
    static long gcd2(long a, long b) {
        if (a == 0) {
            return b;
        }
        if (b == 0) {
            return a;
        }
        long min = Math.min(a, b);
        for (long i = min; i >= 1; i--) {
            if (a % i == 0 && b % i == 0) {
                return i;
            }

        }
        return 1;

    }

}
